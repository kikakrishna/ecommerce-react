import Button from '@mui/material/Button';
import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import { apiClient } from '../Services/Api';


function ProductList() {

    const [Values, setValues] = useState([]);

    useEffect(() => {
        apiClient()
            .get("/getallproducts", {
                headers: { "Content-Type": "application/json" },

            }).then((r) => {
                console.log("analysticsresponse" + JSON.stringify(r.data.data));

                var temparr = []
                temparr.push(r.data.data)

                temparr.flat()
                console.log(temparr);
                setValues(...temparr)
                // Values.flat()

                console.log(Values);
            });
    }, []);

    const [showModal, setShow] = useState(false);
    const [Image, setImage] = useState("");

    const handleClose = () => {
        setShow(false);
        setEdit(false)

    }
    const handleShow = () => {
        setShow(true);

        console.log(Values);

    }

    const [formData, setFormData] = useState({
        name: '',
        code: '',
        category: '',
        image: null,
        description: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleImageChange = (e) => {
        var file = e.target.files[0];

        console.log(Image);

        setImage(file)

        setFormData({ ...formData, image: file });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        console.log(Image.pictureAsFile);
        console.log("base64-----------------------------", filebase64);

        const formDataToSend = new FormData();
        formDataToSend.append('name', formData.name);
        formDataToSend.append('code', formData.code);
        formDataToSend.append('category', formData.category);
        formDataToSend.append('image', filebase64);
        formDataToSend.append('description', formData.description);
        // console.log(Image);

        apiClient()
            .post("/addproduct", formDataToSend, {
                headers: { "Content-Type": "application/json" },

            }).then((r) => {
                console.log("analysticsresponse" + JSON.stringify(r.data.isError));


            });

    };

    const [filebase64, setFileBase64] = useState("")
    const [showModaledit, setEdit] = useState(false);

    const convertFile = (files) => {
        if (files) {
            const fileRef = files[0] || ""
            const fileType = fileRef.type || ""
            // console.log("This file upload is of type:", fileType)
            const reader = new FileReader()
            reader.readAsBinaryString(fileRef)
            reader.onload = (ev) => {
                // convert it to base64
                setFileBase64(`data:${fileType};base64,${btoa(ev.target.result)}`)
            }
        }
    }
    const [editVlues, seteditVlues] = useState({
        name: '',
        code: '',
        category: '',
        image: null,
        description: '',
    })

    // const [formData, setFormData] = useState({
    //     name: '',
    //     code: '',
    //     category: '',
    //     image: null,
    //     description: '',
    // });

    const handleClick = (x) => {
        console.log(x);
        setEdit(true)
        seteditVlues(x)

    };



    const handleInputeditChange = (e) => {
        const { name, value } = e.target;
        seteditVlues({ ...editVlues, [name]: value });
    };



    const handleSubmitedit = (e) => {
        e.preventDefault();

        console.log(Image.pictureAsFile);
        console.log("base64-----------------------------", filebase64);
        // let json = {
        //     'name': editVlues.name,
        //     'code': editVlues.code,
        //     'category': editVlues.category,
        //     'image': filebase64,
        //     'description': editVlues.description
        // }

        // console.log(json);
        const formDataToSend = new FormData();
        formDataToSend.append('name', editVlues.name);
        formDataToSend.append('code', editVlues.code);
        formDataToSend.append('category', editVlues.category);
        formDataToSend.append('image', filebase64);
        formDataToSend.append('description', editVlues.description);
        formDataToSend.append('id', editVlues.id);

        // console.log(Image);

        apiClient()
            .put("/updateproduct", formDataToSend, {
                headers: { "Content-Type": "application/json" },

            }).then((r) => {

                console.log("analysticsresponse" + JSON.stringify(r.data.isError));
                apiClient()
                    .get("/getallproducts", {
                        headers: { "Content-Type": "application/json" },

                    }).then((r) => {
                        console.log("analysticsresponse" + JSON.stringify(r.data.data));

                        var temparr = []
                        temparr.push(r.data.data)

                        temparr.flat()
                        console.log(temparr);
                        setValues(...temparr)
                        // Values.flat()

                        console.log(Values);
                    });

            });

    };

    return (
        <div className="container-fluid">




            <div className='add-button'>
                <Button variant="contained" onClick={handleShow}>Add Product</Button>

            </div>

            <div>
                <div class="container">
                    <div class="row">
                        {Values.map((x, i) => (


                            <div className='col lg-3 xl-3 md-3 grid-vew'>
                                <img src={x.image} />
                                <p key={i}>{x.name}</p>
                                <p key={i}>{x.category}</p>
                                <p key={i}>{x.description}</p>
                                <p key={i}>{x.name}</p>
                                <Button onClick={() => handleClick(x)}>Edit</Button>

                            </div>

                        ))}

                    </div>
                </div>


            </div >


            <div
                className="d-flex align-items-center justify-content-center"
                style={{ height: "100vh" }}
            >
                {/* <Button variant="primary" onClick={handleShow}>
                    Launch demo modal
                </Button> */}
            </div>
            <Modal show={showModal} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Add Product</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    <form onSubmit={handleSubmit}>
                        <div>
                            <input
                                type="text"
                                name="name"
                                placeholder="Name"
                                value={formData.name}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="code"
                                placeholder="Code"
                                value={formData.code}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="category"
                                placeholder="Category"
                                value={formData.category}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div>
                            <input
                                type="file"
                                name="image"
                                // onChange={handleImageChange}
                                onChange={(e) => convertFile(e.target.files)}
                            />
                        </div>
                        <div>
                            <textarea
                                name="description"
                                placeholder="Description"
                                value={formData.description}
                                onChange={handleInputChange}
                            />
                        </div>
                        <div>
                            <button type="submit">Save</button>
                        </div>
                    </form>

                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>

                </Modal.Footer>
            </Modal>

            <Modal show={showModaledit} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Product</Modal.Title>
                </Modal.Header>
                <Modal.Body>

                    <form onSubmit={handleSubmitedit}>
                        <div>
                            <input
                                type="text"
                                name="name"
                                placeholder="Name"
                                value={editVlues.name}
                                onChange={handleInputeditChange}
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="code"
                                placeholder="Code"
                                value={editVlues.code}
                                onChange={handleInputeditChange}
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="category"
                                placeholder="Category"
                                value={editVlues.category}
                                onChange={handleInputeditChange}
                            />
                        </div>
                        <div>
                            <input
                                type="file"
                                name="image"
                                // onChange={handleImageChange}
                                onChange={(e) => convertFile(e.target.files)}
                            />
                        </div>
                        <div>
                            <textarea
                                name="description"
                                placeholder="Description"
                                value={editVlues.description}
                                onChange={handleInputeditChange}
                            />
                        </div>
                        <div>
                            <button type="submit">Save</button>
                        </div>
                    </form>

                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>

                </Modal.Footer>
            </Modal>


        </div >
    );
}

export default ProductList;
